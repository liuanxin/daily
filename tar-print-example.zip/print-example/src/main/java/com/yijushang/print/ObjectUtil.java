package com.yijushang.print;

import com.google.common.collect.Maps;

import java.beans.PropertyDescriptor;
import java.io.*;
import java.lang.reflect.Method;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.StandardCharsets;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.*;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/** 工具类 */
public final class ObjectUtil {

    public static final Random RANDOM = new Random();

    /** 本机的 cpu 核心数 */
    public static final int PROCESSORS = Runtime.getRuntime().availableProcessors();

    public static final String EMPTY = "";
    public static final String BLANK = " ";

    /**
     * 字符串长度 >= 这个值, 才进行压缩
     *
     * 字符串压缩时, 将字符串先操作 gzip 再编码成 base64 字符串
     * 解压字符串时, 将字符串先解码 base64 再操作 gzip 解压
     */
    private static final int COMPRESS_MIN_LEN = 1000;

    private static final String TEMP = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";

    /** 生成指定位数的随机数: 纯数字 */
    public static String random(int length) {
        if (length <= 0) {
            return EMPTY;
        }

        StringBuilder sbd = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sbd.append(RANDOM.nextInt(10));
        }
        return sbd.toString();
    }

    /** 生成指定位数的随机数: 数字和字母 */
    public static String randomLetterAndNumber(int length) {
        if (length <= 0) {
            return EMPTY;
        }

        StringBuilder sbd = new StringBuilder();
        for (int i = 0; i < length; i++) {
            sbd.append(TEMP.charAt(RANDOM.nextInt(TEMP.length())));
        }
        return sbd.toString();
    }

    /** 传入的数不为 null 且 大于 0 就返回 true */
    public static boolean greater0(Number obj) {
        return obj != null && obj.doubleValue() > 0;
    }

    /** 传入的数为 null 或 小于等于 0 就返回 true */
    public static boolean lessAndEquals0(Number obj) {
        return !greater0(obj);
    }

    /** 传入的数不为 null 且 大于等于 0 就返回 true */
    public static boolean greaterAndEquals0(Number obj) {
        return obj != null && obj.doubleValue() >= 0;
    }

    /** 传入的数为 null 或 小于 0 就返回 true(等于 0 时返回 false) */
    public static boolean less0(Number obj) {
        return !greaterAndEquals0(obj);
    }

    /** 转换成 int, 非数字则返回 0 */
    public static int toInt(Object obj) {
        if (isBlank(obj)) {
            return 0;
        }
        if (obj instanceof Number) {
            return ((Number) obj).intValue();
        }
        try {
            return Integer.parseInt(obj.toString().trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    /** 转换成 long, 非数字则返回 0L */
    public static long toLong(Object obj) {
        if (isBlank(obj)) {
            return 0L;
        }
        if (obj instanceof Number) {
            return ((Number) obj).longValue();
        }
        try {
            return Long.parseLong(obj.toString().trim());
        } catch (NumberFormatException e) {
            return 0L;
        }
    }

    /** 转换成 float, 非数字则返回 0F */
    public static float toFloat(Object obj) {
        if (isBlank(obj)) {
            return 0F;
        }
        if (obj instanceof Number) {
            return ((Number) obj).floatValue();
        }
        try {
            return Float.parseFloat(obj.toString().trim());
        } catch (NumberFormatException e) {
            return 0F;
        }
    }

    /** 转换成 double, 非数字则返回 0D */
    public static double toDouble(Object obj) {
        if (isBlank(obj)) {
            return 0D;
        }
        if (obj instanceof Number) {
            return ((Number) obj).doubleValue();
        }
        try {
            return Double.parseDouble(obj.toString().trim());
        } catch (NumberFormatException e) {
            return 0D;
        }
    }

    /** 是数字则返回 true */
    public static boolean isNumber(Object obj) {
        if (isBlank(obj)) {
            return false;
        }
        if (obj instanceof Number) {
            return true;
        }
        try {
            Double.parseDouble(obj.toString().trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /** 不是数字则返回 true */
    public static boolean isNotNumber(Object obj) {
        return !isNumber(obj);
    }

    /** 将数值转换成 ipv4, 类似于 mysql 中 INET_NTOA(134744072) ==> 8.8.8.8 */
    public static String num2ip(long num) {
        return ((num & 0xff000000) >> 24) + "." + ((num & 0xff0000) >> 16)
                + "." + ((num & 0xff00) >> 8) + "." + ((num & 0xff));
    }

    public static String toStr(Object obj) {
        return isBlank(obj) ? EMPTY : obj.toString();
    }

    /** 对象长度: 中文字符的长度为 2, 其他字符的长度为 1 */
    public static int toLen(Object obj) {
        if (isNull(obj)) {
            return 0;
        }

        int count = 0;
        String str = obj.toString();
        for (int i = 0; i < str.length(); i++) {
            count += (str.substring(i, i + 1).matches("[\\u4e00-\\u9fa5]") ? 2 : 1);
        }
        return count;
    }

    /** 对象为 null 时返回 true */
    public static boolean isNull(Object obj) {
        return obj == null;
    }
    /** 对象不为 null 时返回 true */
    public static boolean isNotNull(Object obj) {
        return obj != null;
    }

    /** 对象为空 或 其字符串形态是空字符 时返回 true */
    public static boolean isBlank(Object obj) {
        return obj == null || EMPTY.equals(obj.toString().trim());
    }
    /** 对象非空 且 其字符串形态不是空字符 时返回 true */
    public static boolean isNotBlank(Object obj) {
        return !isBlank(obj);
    }

    /** 对象为空 或 其字符串形态为 空白符、null、undefined 时返回 true */
    public static boolean isEmpty(Object obj) {
        if (obj == null) {
            return true;
        }

        String str = obj.toString().trim();
        if (EMPTY.equals(str)) {
            return true;
        }

        String lower = str.toLowerCase();
        return "null".equals(lower) || "undefined".equals(lower);
    }
    /** 对象非空 且 其字符串形态不是 空白符、null、undefined 时返回 true */
    public static boolean isNotEmpty(Object obj) {
        return !isEmpty(obj);
    }

    public static <T> T defaultIfNull(T obj, T defaultValue) {
        return isNull(obj) ? defaultValue : obj;
    }

    /** 生成不带 - 的 uuid */
    public static String uuid() {
        return UUID.randomUUID().toString().replace("-", EMPTY);
    }
    /** 生成 16 的 uuid */
    public static String uuid16() {
        return uuid().substring(8, 24);
    }

    /** 为空则返回 /, 如果开头有 / 则直接返回, 否则在开头拼接 / 并返回 */
    public static String addPrefix(String src) {
        if (isBlank(src)) {
            return "/";
        }
        if (src.startsWith("/")) {
            return src;
        }
        return "/" + src;
    }
    /** 为空则返回 /, 如果结尾有 / 则直接返回, 否则在结尾拼接 / 并返回 */
    public static String addSuffix(String src) {
        if (isBlank(src)) {
            return "/";
        }
        if (src.endsWith("/")) {
            return src;
        }
        return src + "/";
    }
    /** 拼接域名和地址, 在两者之间加 /, 如果域名末尾没有 / 则加上, 地址前面有 / 则去掉 */
    public static String appendUrl(String domain, String path) {
        return addSuffix(domain) + (path.startsWith("/") ? path.substring(1) : path);
    }
    /** 从 url 中获取最后一个 斜杆(/) 后的内容 */
    public static String getFileNameInUrl(String url) {
        if (isBlank(url) || !url.contains("/")) {
            return EMPTY;
        }
        // 只截取到 ? 处, 如果有的话
        int last = url.contains("?") ? url.lastIndexOf("?") : url.length();
        return url.substring(url.lastIndexOf("/") + 1, last);
    }

    /** 获取指定类所在 jar 包的地址 */
    public static String getClassInFile(Class<?> clazz) {
        if (isNotBlank(clazz)) {
            ProtectionDomain domain = clazz.getProtectionDomain();
            if (isNotBlank(domain)) {
                CodeSource source = domain.getCodeSource();
                if (isNotBlank(source)) {
                    URL location = source.getLocation();
                    if (isNotBlank(location)) {
                        return location.getFile();
                    }
                }
            }
        }
        return null;
    }

    /**
     * <pre>
     * try (
     *     InputStream input = ...;
     *     OutputStream output = ...;
     * ) {
     *     inputToOutput(input, output);
     * }
     * </pre>
     */
    public static void inputToOutput(InputStream input, OutputStream output) {
        try {
            // guava
            // ByteStreams.copy(inputStream, outputStream);

            // jdk-8
            byte[] buf = new byte[8192];
            int length;
            while ((length = input.read(buf)) != -1) {
                output.write(buf, 0, length);
            }
            // jdk-9
            // inputStream.transferTo(outputStream);
        } catch (IOException e) {
            throw new RuntimeException("input to output exception", e);
        }
    }

    /**
     * <pre>
     * try (
     *         InputStream inputStream = ...;
     *         OutputStream outputStream = ...;
     *
     *         ReadableByteChannel input = Channels.newChannel(inputStream);
     *         WritableByteChannel output = Channels.newChannel(outputStream);
     * ) {
     *     inputToOutputWithChannel(input, output);
     * }
     * </pre>
     */
    public static void inputToOutputWithChannel(ReadableByteChannel input, WritableByteChannel output) {
        try {
            ByteBuffer buffer = ByteBuffer.allocateDirect(8192);
            while (input.read(buffer) != -1) {
                buffer.flip();
                output.write(buffer);
                buffer.clear();
            }
        } catch (IOException e) {
            throw new RuntimeException("input to output with channel exception", e);
        }
    }

    /** 将长字符串进行 gzip 压缩后再转成 base64 编码返回 */
    public static String compress(final String str) {
        if (str == null) {
            return null;
        }
        String trim = str.trim();
        if (EMPTY.equals(trim) || trim.length() < COMPRESS_MIN_LEN) {
            return trim;
        }

        try (
                ByteArrayOutputStream output = new ByteArrayOutputStream();
                GZIPOutputStream gzip = new GZIPOutputStream(output)
        ) {
            gzip.write(trim.getBytes(StandardCharsets.UTF_8));
            gzip.finish();
            return new String(Base64.getEncoder().encode(output.toByteArray()), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return trim;
        }
    }

    /** 将压缩的字符串用 base64 解码再进行 gzip 解压 */
    public static String decompress(String str) {
        if (isNull(str)) {
            return null;
        }
        String trim = str.trim();
        if (EMPTY.equals(trim)) {
            return trim;
        }
        // 如果字符串以 { 开头且以 } 结尾, 或者以 [ 开头以 ] 结尾(json)则不解压, 直接返回
        if ((str.startsWith("{") && str.endsWith("}")) || (str.startsWith("[") && str.endsWith("]"))) {
            return trim;
        }

        byte[] bytes;
        try {
            bytes = Base64.getDecoder().decode(str.getBytes(StandardCharsets.UTF_8));
        } catch (Exception e) {
            return trim;
        }
        if (bytes.length == 0) {
            return trim;
        }

        try (
                ByteArrayInputStream input = new ByteArrayInputStream(bytes);
                GZIPInputStream gis = new GZIPInputStream(input);

                InputStreamReader in = new InputStreamReader(gis, StandardCharsets.UTF_8);
                final BufferedReader bufferedReader = new BufferedReader(in)
        ) {
            StringBuilder sbd = new StringBuilder();
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                sbd.append(line);
            }
            return sbd.toString();
        } catch (Exception e) {
            return trim;
        }
    }
}
