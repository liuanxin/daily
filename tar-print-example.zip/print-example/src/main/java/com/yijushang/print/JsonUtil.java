package com.yijushang.print;

import com.fasterxml.jackson.databind.*;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JsonUtil {

    public static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * 把对象转成json字符串,不包含null字段
     */
    public static String toJson(Object o) {
        try {
            return objectMapper.writeValueAsString(o);
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("不能序列化对象为Json", e);
            }
            return "";
        }
    }

    /**
     * 将 json 字段串转换为对象.
     *
     * @param json  字符串
     * @param clazz 需要转换为的类
     */
    public static <T> T toObject(String json, Class<T> clazz) {
        try {
            return objectMapper.readValue(json, clazz);
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("将 Json 转换为对象时异常,数据(" + json + ")", e);
            }
            return null;
        }
    }

}
