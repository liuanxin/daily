package com.yijushang.print;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import java.io.ByteArrayOutputStream;
import java.util.List;
import java.util.Map;

/**
 * 处理打印的工具类.
 *
 * Created on 14-9-18.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public class PrintUtil {

    /** 中文粗体, 物流单 */
    private static final Font CHINESE_FONT_BOLD;

    /** 中文字体. 发货单 */
    private static final Font CHINESE_FONT;
    /** 小一号的中文字体. 发货单中间的数据 */
    private static final Font CHINESE_SMALL_FONT;
    static {
        BaseFont baseFont;
        try {
            baseFont = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
        } catch (Exception e) {
            baseFont = new FontFactoryImp().getFont(FontFactory.COURIER).getBaseFont();
        }
        CHINESE_FONT = new Font(baseFont, PrintSendConstant.DEFAULT_FONT);
        CHINESE_SMALL_FONT = new Font(baseFont, PrintSendConstant.DEFAULT_SMALL_FONT);

        BaseFont baseFontBold;
        try {
            baseFontBold = BaseFont.createFont("STSong-Light,Bold", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
        } catch (Exception e) {
            baseFontBold = new FontFactoryImp().getFont(FontFactory.COURIER_BOLD).getBaseFont();
        }
        CHINESE_FONT_BOLD = new Font(baseFontBold, PrintConstant.DEFAULT_FONT);
    }


    /**
     * <pre>
     * 生成物流单.
     * ByteArrayOutputStream baos = PrintUtil.previewPrintPdf(x, x, x, x);
     *
     * response.setContentType("application/pdf");
     * response.setHeader("Expires", "0");
     * response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
     * response.setHeader("Pragma", "public");
     * response.setContent.size()(baos.size());
     *
     * OutputStream os = response.getOutputStream();
     * baos.writeTo(os);
     *
     * os.flush();
     * os.close();
     * </pre>
     *
     * @param templateContent pdf 模板内容(json 字串)
     * @param mapList 生成 pdf 的内容
     * @param author 设置的 pdf 作者
     * @param title 设置的 pdf 标题
     * @return 供前台导出的流
     */
    public static ByteArrayOutputStream generatePrintPdf(String templateContent, List<Map<String, Object>> mapList,
                                                         String author, String title) {
        return previewPrintPdf(templateContent, StringUtils.EMPTY, mapList, author, title);
    }

    /**
     * <pre>
     * 生成物流单.
     * ByteArrayOutputStream baos = PrintUtil.previewPrintPdf(x, x, x, x);
     *
     * response.setContentType("application/pdf");
     * response.setHeader("Expires", "0");
     * response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
     * response.setHeader("Pragma", "public");
     * response.setContent.size()(baos.size());
     *
     * OutputStream os = response.getOutputStream();
     * baos.writeTo(os);
     *
     * os.flush();
     * os.close();
     * </pre>
     *
     * @param templateContent pdf 模板内容(json 字串)
     * @param previewPath 水印图片背景路径
     * @param mapList 生成 pdf 的内容
     * @param author 设置的 pdf 作者
     * @param title 设置的 pdf 标题
     * @return 供前台导出的流
     */
    public static ByteArrayOutputStream previewPrintPdf(String templateContent, String previewPath,
                                                        List<Map<String, Object>> mapList,
                                                        String author, String title) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        Map templateMap = JsonUtil.toObject(templateContent, Map.class);
        Object size = templateMap.remove(PrintConstant.SIZE.getName());
        if (!(size instanceof List) || ((List) size).size() < 2
                || NumberUtils.toFloat(((List) size).get(0).toString()) < 0
                || NumberUtils.toFloat(((List) size).get(1).toString()) < 0) {
            throw new RuntimeException("尺寸必须设置成两位正整数");
        }
        // 宽高
        float width = NumberUtils.toFloat(((List) size).get(0).toString());
        float height = NumberUtils.toFloat(((List) size).get(1).toString());
        // 整体偏移量
        float offsetX = 0, offsetY = 0;
        Object offset = templateMap.remove(PrintConstant.OFFSET.getName());
        if ((offset instanceof List) && ((List) offset).size() > 1) {
            offsetX = NumberUtils.toFloat(((List) offset).get(0).toString());
            offsetY = NumberUtils.toFloat(((List) offset).get(1).toString());
        }
        // 字号
        int defaultFont = PrintConstant.DEFAULT_FONT;
        Object fontConstant = templateMap.remove(PrintConstant.FONT.getName());
        if (fontConstant != null && NumberUtils.toInt(fontConstant.toString()) > 0) {
            defaultFont = NumberUtils.toInt(fontConstant.toString());
        }

        try {
            Document document = new Document();

            Rectangle pageSize = new Rectangle(width, height);
            document.setPageSize(pageSize);
            document.addAuthor(author);
            document.addCreator(author);
            document.addTitle(title);
            PdfWriter writer = PdfWriter.getInstance(document, outputStream);

            document.open();
            PdfContentByte canvas = writer.getDirectContent();

            boolean isPreview = false;
            if (StringUtils.isNotBlank(previewPath)) {
                try {
                    // 加水印
                    Image image = Image.getInstance(previewPath);
                    // 图片占满整个 pdf
                    image.scaleAbsolute(pageSize);
                    image.setAbsolutePosition(0, 0);
                    // 图片平铺, 解开下面这一句, 注释上面两句
                    //image.setAbsolutePosition(0, height - image.getHeight());
                    canvas.addImage(image);
                    isPreview = true;
                } catch (Exception e) {
                    // ignore with log
                }
            }
            for (int i = 0; i < mapList.size(); i++) {
                // 每一页物流单的数据
                Map<String, Object> map = mapList.get(i);

                for (Object entry : templateMap.keySet()) {
                    Object value = templateMap.get(entry);
                    // 数据项, 需要的数据从订单或物流中获取
                    if (value instanceof List) {
                        List infoArr = (List) value;
                        if (PrintConstant.DIY.getName().equals(entry.toString())) {
                            // 自定义内容项是一个二维数组
                            for (Object array : infoArr) {
                                // 每一个自定义项的长度至少要有三位, 且第一位跟第二位要能转换成正整数, 第三位不能为空
                                if ((array instanceof List) && ((List) array).size() >= 3) {
                                    List arrObj = (List) array;
                                    int infoX = NumberUtils.toInt(arrObj.get(0).toString());
                                    int infoY = NumberUtils.toInt(arrObj.get(1).toString());
                                    String content = arrObj.get(2).toString();
                                    if (infoX >= 0 && infoY >= 0 && StringUtils.isNotBlank(content)) {
                                        handleText(canvas, content, arrObj, defaultFont, 3, 4, false,
                                                isPreview, height, infoX, infoY, offsetX, offsetY);
                                    }
                                }
                            }
                        } else {
                            // 数据项的长度至少要有两位, 且第一位和第二位要能转换成正整数, 且其对应的内容要有值
                            if (infoArr.size() >= 2) {
                                int infoX = NumberUtils.toInt(infoArr.get(0).toString());
                                int infoY = NumberUtils.toInt(infoArr.get(1).toString());
                                Object contentObj = map.get(entry.toString());
                                if (infoX >= 0 && infoY >= 0 && contentObj != null && StringUtils.isNotBlank(contentObj.toString())) {
                                    // 特殊换行的项
                                    boolean special = PrintConstant.getSpecialConst().contains(entry.toString());
                                    handleText(canvas, contentObj.toString(), infoArr, defaultFont, 2, 3, special,
                                            isPreview, height, infoX, infoY, offsetX, offsetY);
                                }
                            }
                        }
                    }
                }
                if (i != mapList.size() - 1) {
                    document.newPage();
                }
            }

            document.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("生成物流单时异常: " + e.getMessage());
        }
        return outputStream;
    }

    /** 处理文字! 设置字体和换行 */
    private static void handleText(PdfContentByte canvas, String content, List arrObj,
                                   int defaultFont, int fontIndex, int splitIndex, boolean special,
                                   boolean isPreview, float height, float infoX, float infoY,
                                   float offsetX, float offsetY) {
        // 字体(粗体)
        int font = getFont(defaultFont, arrObj, fontIndex);
        canvas.beginText();
        canvas.setFontAndSize(CHINESE_FONT_BOLD.getBaseFont(), font);

        // x 和 y, 都算上各自的偏移量
        float x = infoX + (isPreview ? 0 : offsetX);
        float y = height - (infoY + (isPreview ? 0 : offsetY) + font);
        int splitCount = NumberUtils.toInt(arrObj.get(splitIndex).toString());
        if (arrObj.size() > splitIndex && splitCount > 0) {
            // 需要特殊处理的换行项
            if (special) {
                int count = 1, splitLength;
                String replaceStr;
                while (content.indexOf(PrintConstant.SPECIAL_SPLIT) > 1) {
                    splitLength = content.split(PrintConstant.SPECIAL_SPLIT).length;
                    replaceStr = (splitLength == 1) ? StringUtils.EMPTY : (count % splitCount != 0) ? " , " : "\n";
                    content = content.replaceFirst(PrintConstant.SPECIAL_SPLIT, replaceStr);
                    count++;
                }

                for (String str : content.trim().split("\n")) {
                    canvas.showTextAligned(PdfContentByte.ALIGN_LEFT, str, x, y, 0);
                    y -= (font + 4);
                }
            } else {
                int loopCount = content.length() / splitCount + 1;
                for (int i = 0; i < loopCount; i++) {
                    int start = splitCount * i;
                    int end = (i + 1 == loopCount) ? content.length() : splitCount * (i + 1);
                    canvas.showTextAligned(PdfContentByte.ALIGN_LEFT, handleTrim(content.substring(start, end)), x, y, 0);
                    y -= (font + 4);
                }
            }
        } else {
            canvas.showTextAligned(PdfContentByte.ALIGN_LEFT, handleTrim(content), x, y, 0);
        }
        canvas.endText();
    }

    /**
     * <pre>
     * 生成发货单.
     *
     * ByteArrayOutputStream outputStream = PrintUtil.generateSendPdf(x, x, x);
     *
     * response.setContentType("application/pdf");
     * response.setHeader("Expires", "0");
     * response.setHeader("Cache-Control", "must-revalidate, post-check=0, pre-check=0");
     * response.setHeader("Pragma", "public");
     * response.setContentLength(outputStream.size());
     *
     * OutputStream os = response.getOutputStream();
     * outputStream.writeTo(os);
     *
     * os.flush();
     * os.close();
     * </pre>
     *
     * @param mapList 生成 pdf 的内容
     * @param author 设置的 pdf 作者
     * @param title 设置的 pdf 标题
     * @return 供前台导出的流
     */
    public static ByteArrayOutputStream generateSendPdf(List<Map<String, Object>> mapList,
                                                        String author, String title) {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

        try {
            Document document = new Document();
            document.setPageSize(new Rectangle(PrintSendConstant.WIDTH, PrintSendConstant.HEIGHT));
            document.addAuthor(author);
            document.addTitle(title);
            PdfWriter writer = PdfWriter.getInstance(document, outputStream);
            document.open();
            PdfContentByte canvas = writer.getDirectContent();

            for (int i = 0; i < mapList.size(); i++) {
                Map<String, Object> sendPrintMap = mapList.get(i);
                // 必须要有商品项
                Object ois = sendPrintMap.get(PrintSendConstant.ORDER_ITEMS.getName());
                if (ois instanceof List && ((List) ois).size() > 0) {
                    List<Map<String, Object>> orderItems = (List) ois;
                    int loopCount = (orderItems.size() > PrintSendConstant.PRODUCT_ITEM_COUNT)
                            ? orderItems.size() / PrintSendConstant.PRODUCT_ITEM_COUNT + 1 : 1;
                    for (int j = 0; j < loopCount; j++) {
                        PdfPTable table = new PdfPTable(4);
                        table.addCell(getFirstTableCell1(PrintSendConstant.RECEIPT_NAME.getDesc()));
                        table.addCell(getFirstTableCell1(sendPrintMap.get(PrintSendConstant.RECEIPT_NAME.getName())));
                        table.addCell(getFirstTableCell1(PrintSendConstant.EXPRESS_COMPANY.getDesc()));
                        table.addCell(getFirstTableCell1(sendPrintMap.get(PrintSendConstant.EXPRESS_COMPANY.getName())));

                        table.addCell(getFirstTableCell1(PrintSendConstant.RECEIPT_PHONE.getDesc()));
                        table.addCell(getFirstTableCell1(sendPrintMap.get(PrintSendConstant.RECEIPT_PHONE.getName())));
                        table.addCell(getFirstTableCell1(PrintSendConstant.EXPRESS_NO.getDesc()));
                        table.addCell(getFirstTableCell1(sendPrintMap.get(PrintSendConstant.EXPRESS_NO.getName())));

                        table.addCell(getFirstTableCell1(PrintSendConstant.RECEIPT_ADDRESS.getDesc()));
                        // 一列占三列
                        table.addCell(getFirstTableCell3(sendPrintMap.get(PrintSendConstant.RECEIPT_ADDRESS.getName())));

                        table.addCell(getFirstTableCell1(PrintSendConstant.RECEIPT_REMARK.getDesc()));
                        // 一列占三列
                        table.addCell(getFirstTableCell3(sendPrintMap.get(PrintSendConstant.RECEIPT_REMARK.getName())));
                        // 设置整体列宽
                        table.setTotalWidth(PrintSendConstant.START_TABLE_WIDTH);
                        float y = PrintSendConstant.FIRST_Y;
                        table.writeSelectedRows(0, -1, PrintSendConstant.FIRST_X, y, canvas);
                        y -= (table.getTotalHeight() + 6);


                        List<PrintSendConstant> productItems = PrintSendConstant.getTableItems();
                        table = new PdfPTable(productItems.size() + 1);
                        table.addCell(getSecondTableCellWithHead("序号"));
                        for (PrintSendConstant printSend : productItems) {
                            table.addCell(getSecondTableCellWithHead(printSend.getDesc()));
                        }
                        int innerLoopCount = (j + 1 == loopCount) ? orderItems.size() : PrintSendConstant.PRODUCT_ITEM_COUNT * (j + 1);
                        for (int k = PrintSendConstant.PRODUCT_ITEM_COUNT * j; k < innerLoopCount; k++) {
                            table.addCell(getSecondTableCell(String.valueOf(k + 1)));

                            Map<String, Object> orderItem = orderItems.get(k);
                            for (PrintSendConstant printSend : productItems) {
                                table.addCell(getSecondTableCell(orderItem.get(printSend.getName())));
                            }
                        }
                        // 表格虚线
                        if (PrintSendConstant.IS_LINE_DASH) {
                            canvas.setLineDash(1f, 4f, 1f);
                        }
                        table.setTotalWidth(PrintSendConstant.CENTER_TABLE_WIDTH);
                        table.writeSelectedRows(0, -1, PrintSendConstant.FIRST_X, y, canvas);
                        y -= (table.getTotalHeight() + 6);


                        table = new PdfPTable(2);
                        table.addCell(getThirdTableCell(PrintSendConstant.ORDER_POSTAGE.getDesc(), Element.ALIGN_LEFT));
                        table.addCell(getThirdTableCell(sendPrintMap.get(PrintSendConstant.ORDER_POSTAGE.getName())
                                + " 元", Element.ALIGN_RIGHT));

                        table.addCell(getThirdTableCell(PrintSendConstant.TOTAL_PRICE.getDesc(), Element.ALIGN_LEFT));
                        table.addCell(getThirdTableCell(sendPrintMap.get(PrintSendConstant.TOTAL_PRICE.getName())
                                + " 元", Element.ALIGN_RIGHT));
                        table.setTotalWidth(PrintSendConstant.THIRD_TABLE_WIDTH);
                        table.writeSelectedRows(0, -1, PrintSendConstant.LAST_X, y, canvas);


                        table = new PdfPTable(2);
                        table.addCell(getEndTableCell(PrintSendConstant.ORDER_NO.getDesc()));
                        table.addCell(getEndTableCell(sendPrintMap.get(PrintSendConstant.ORDER_NO.getName())));

                        table.addCell(getEndTableCell(PrintSendConstant.SEND_NAME.getDesc()));
                        table.addCell(getEndTableCell(sendPrintMap.get(PrintSendConstant.SEND_NAME.getName())));

                        table.addCell(getEndTableCell(PrintSendConstant.SEND_ADDRESS.getDesc()));
                        table.addCell(getEndTableCell(sendPrintMap.get(PrintSendConstant.SEND_ADDRESS.getName())));

                        table.addCell(getEndTableCell(PrintSendConstant.SEND_REMARK.getDesc()));
                        table.addCell(getEndTableCell(sendPrintMap.get(PrintSendConstant.SEND_REMARK.getName())));
                        table.setTotalWidth(PrintSendConstant.END_TABLE_WIDTH);
                        table.writeSelectedRows(0, -1, PrintSendConstant.FIRST_X, PrintSendConstant.LAST_Y, canvas);

                        // 一个订单可能会有多张发货单
                        if (j != loopCount - 1) {
                            document.newPage();
                        }
                    }
                    // 多个订单要加页
                    if (i != mapList.size() - 1) {
                        document.newPage();
                    }
                }
            }
            document.add(new Chunk(StringUtils.EMPTY));
            document.close();
        } catch (Exception e) {
            throw new RuntimeException("生成发货单时异常: " + e.getMessage());
        }
        return outputStream;
    }

    /** 获取每个项的字体, 若未设置则使用默认字体 */
    private static int getFont(int defaultFont, List infoArr, int index) {
        int font = defaultFont;
        if (infoArr != null && infoArr.size() > index) {
            int infoFont = NumberUtils.toInt(infoArr.get(index).toString());
            if (infoFont > 0 && infoFont != defaultFont) {
                font = infoFont;
            }
        }
        return font;
    }

    private static PdfPCell getFirstTableCell1(Object content) {
        return getCell(PrintSendConstant.ROW_HEIGHT, content, 1, false, Element.ALIGN_LEFT, true);
    }
    private static PdfPCell getFirstTableCell3(Object content) {
        return getCell(PrintSendConstant.ROW_HEIGHT, content, 3, false, Element.ALIGN_LEFT, true);
    }
    private static PdfPCell getSecondTableCellWithHead(Object content) {
        PdfPCell cell = getCell(PrintSendConstant.TABLE_ROW_HEIGHT, content, 1, true, Element.ALIGN_CENTER, false);
        cell.setBackgroundColor(new BaseColor(210, 210, 210));
        return cell;
    }
    private static PdfPCell getSecondTableCell(Object content) {
        return getCell(PrintSendConstant.TABLE_ROW_HEIGHT, content, 1, true, Element.ALIGN_CENTER, false);
    }
    private static PdfPCell getThirdTableCell(Object content, int align) {
        return getCell(PrintSendConstant.ROW_HEIGHT, content, 1, false, align, false);
    }
    private static PdfPCell getEndTableCell(Object content) {
        return getCell(PrintSendConstant.ROW_HEIGHT, content, 1, false, Element.ALIGN_LEFT, true);
    }
    private static PdfPCell getCell(int height, Object content, int colSpan, boolean border, int align, boolean bigFont) {
        PdfPCell cell = new PdfPCell(new Phrase(handleNil(content), bigFont ? CHINESE_FONT : CHINESE_SMALL_FONT));
        cell.setMinimumHeight(height);
        if (colSpan > 1) {
            cell.setColspan(colSpan);
        }
        if (!border) {
            cell.setBorder(PdfPCell.NO_BORDER);
        }

        cell.setUseAscender(true);
        cell.setHorizontalAlignment(align);
        cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return cell;
    }

    /** 英文或数字可能会因为上面的中文字体而显得过于紧凑, 加一个空格处理一下 */
    private static String handleTrim(Object contentObj) {
        return contentObj.toString().replaceAll("(\\w)", " $1 ").replace("  ", " ").trim();
    }

    private static String handleNil(Object obj) {
        return obj == null ? StringUtils.EMPTY : handleTrim(obj.toString());
    }
}

