package com.yijushang.print;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

@Data
public class PrintInfo {

    /**
     * 宽, 默认是 A4(595)
     * @see com.itextpdf.text.PageSize
     */
    private float width;

    /**
     * 高, 默认是 A4(842)
     * @see com.itextpdf.text.PageSize
     */
    private float height;

    /** x 轴的整体偏移量, 正数则整体向右偏移, 负数则整体向左偏移 */
    private float offsetX = 0F;

    /** y 轴的整体偏移量, 正数则整体向下偏移, 负数则整体向上偏移 */
    private float offsetY = 0F;

    /** 需要做分页的表格头 */
    private PrintPlaceholderTableKey pageTableContentKey;
    /** 需要做分页的表格内容*/
    private List<PrintPlaceholderTableContent> pageTableContentList;

    /** 自定义内容 */
    private List<PrintContent> contentList;

    /** 占位内容 */
    private List<PrintPlaceholderContent> placeholderContentList;

    /** 表格占位内容 */
    private Map<PrintPlaceholderTable, List<PrintPlaceholderTableContent>> placeholderContentListMap;

    public boolean hasSize() {
        return width > 0 && height > 0;
    }
    public boolean nilData() {
        return (contentList != null && !contentList.isEmpty())
                || (placeholderContentList != null && !placeholderContentList.isEmpty())
                || (placeholderContentListMap != null && !placeholderContentListMap.isEmpty());
    }
    public List<?> pageList(Map<String, Object> data) {
        if (pageTableContentKey == null || pageTableContentList == null || pageTableContentList.isEmpty()) {
            return null;
        }
        if (pageTableContentKey.notDraw() || pageTableContentKey.getFieldWidthList().size() != pageTableContentList.size()) {
            return null;
        }
        Object obj = data.get(pageTableContentKey.getFieldName());
        if (!(obj instanceof List)) {
            return null;
        }

        List<?> list = (List<?>) obj;
        return list.isEmpty() ? null : list;
    }

    @Data
    public static class PrintContent {
        /** x 轴表示从左向右, 写的左下的位置 */
        private float x;
        /** y 轴表示从下到上, 写的左下的位置, 要注意写的内容的高 */
        private float y;
        private String value;

        /** 字体大小, 单位 pt(11pt = 14.67px, 15pt = 20px, 20pt = 26.67px) */
        private float fontSize = 11;
        /** 如果上面的 value 过大, 从多少个字符开始下一行 */
        private int splitCount;
        /** 如果内容过多, 最多只显示的行数 */
        private int maxLine;
    }

    @Data
    public static class PrintPlaceholderContent {
        /** x 轴表示从左向右, 写的左下的位置 */
        private float x;
        /** y 轴表示从下到上, 写的左下的位置, 要注意写的内容的高 */
        private float y;

        private PlaceholderType fieldType;
        private String fieldName;

        /** 字体大小, 单位 pt(11pt = 14.67px, 15pt = 20px, 20pt = 26.67px) */
        private float fontSize = 11;
        /** 如果内容过大, 从多少个字符开始下一行 */
        private int splitCount;
        /** 如果内容过多, 最多只显示的行数 */
        private int maxLine;

        /** 二维码、条形码 的宽 */
        private float codeWidth;
        /** 二维码、条形码 的高 */
        private float codeHeight;

        /** 线宽 */
        private float lineWidth;
        /** 线的底色: 0.黑, 1.白 */
        private float lineGray;
    }

    @Data
    public static class PrintPlaceholderTable {
        /** x 轴表示从左向右, 写的左下的位置 */
        private float x;
        /** y 轴表示从下到上, 写的左下的位置, 要注意写的内容的高 */
        private float y;

        private String fieldName;
        /** 表格列宽(每个列的宽) */
        private List<Float> fieldWidthList; // = Arrays.asList(65F, 280F, 65F, 120F);
        /** 是否输出表头 */
        private boolean printHead = true;
        /** 表格头名(如果输出表头, 长度要跟列宽一致) */
        private List<String> fieldHeadList;
        /** 表头背景, rgb 值 */
        private List<Integer> headBackground; // = Arrays.asList(210, 210, 210);
        /** 表头字体大小, 单位 pt(11pt = 14.67px, 15pt = 20px, 20pt = 26.67px) */
        private float fontSize = 11;
        /** 表格头的高, 单位 pt(11pt = 14.67px, 15pt = 20px, 20pt = 26.67px) */
        private int headHeight = 15;
        /** 表格是否有边框 */
        private boolean border = true;
        /** 表格边框是否虚线 */
        private boolean dashLine = false;

        public boolean notDraw() {
            return x < 0 || y < 0 || fieldName == null || "".equals(fieldName.trim())
                    || fieldWidthList == null || fieldWidthList.isEmpty()
                    || fieldHeadList == null || fieldHeadList.isEmpty()
                    || (printHead && fieldWidthList.size() != fieldHeadList.size());
        }
    }

    @Data
    @EqualsAndHashCode(callSuper = true)
    public static class PrintPlaceholderTableKey extends PrintPlaceholderTable {
        /** 单页最多存放个数 */
        private int singlePageCount;
    }

    @Data
    public static class PrintPlaceholderTableContent {
        /** 表格头的数据列 */
        private String fieldName;

        private PlaceholderType fieldType;
        /** 字体大小, 单位 pt(11pt = 14.67px, 15pt = 20px, 20pt = 26.67px) */
        private float fontSize = 11;
        /** 表格行的高, 单位 pt(11pt = 14.67px, 15pt = 20px, 20pt = 26.67px) */
        private int headHeight = 15;
        /** 如果内容过大, 只显示多少个字符 */
        private int maxCount;
    }

    public enum PlaceholderType {
        BARCODE, QRCODE, LINE
    }
}
