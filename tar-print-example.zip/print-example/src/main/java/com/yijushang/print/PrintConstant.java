package com.yijushang.print;

import com.google.common.collect.Maps;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

/**
 * 打印模板中传递的参数字符串 key
 *
 * Created on 14-9-18.
*/
@Getter
@AllArgsConstructor
public enum PrintConstant {

    /** 尺寸 */
    SIZE("cc", "尺寸"),
    /** 偏移量 */
    OFFSET("mv", "偏移量"),
    /** 字号 */
    FONT("ft", "字号"),
    /** 自定义内容 */
    DIY("dy", "自定义内容"),

    // ========== 下面的数据项需要从订单物流处获取 ==========

    /** 寄件方姓名 */
    SEND_NAME("sn", "寄件方姓名"),
    /** 寄件方单位名 */
    SEND_ORGANIZE("so", "寄件方单位名"),
    /** 寄件方详细地址 */
    SEND_ADDRESS("sa", "寄件方详细地址"),
    /** 寄件方手机 */
    SEND_MOBILE("sm", "寄件方手机"),
    /** 寄件方手机/寄件人固话 */
    SEND_CONTACT("sl", "寄件方手机/收件方固话"),
    /** 寄件方固定电话 */
    SEND_TELEPHONE("st", "寄件方固定电话"),
    /** 寄件方邮编 */
    SEND_ZIP("sz", "寄件方邮编"),
    /** 发货时间 */
    SEND_DATE("sd", "发货时间"),
    /** 寄件方所在省 */
    SEND_PROVINCE("sp", "寄件方所在省"),
    /** 寄件方所在市 */
    SEND_CITY("sc", "寄件方所在市"),
    /** 寄件方所在区县 */
    SEND_REGION("sr", "寄件方所在区县"),

    /** 收件方姓名 */
    RECEIPT_NAME("rn", "收件方姓名"),
    /** 收件方详细地址 */
    RECEIPT_ADDRESS("ra", "收件方详细地址"),
    /** 收件方手机 */
    RECEIPT_MOBILE("rm", "收件方手机"),
    /** 收件方手机/收件方固话 */
    RECEIPT_CONTACT("rl", "收件方手机/收件方固话"),
    /** 收件方固定电话 */
    RECEIPT_TELEPHONE("rt", "收件方固定电话"),
    /** 收件方邮编 */
    RECEIPT_ZIP("rz", "收件方邮编"),
    /** 收货方所在省 */
    RECEIPT_PROVINCE("rp", "收货方所在省"),
    /** 收件方所在市 */
    RECEIPT_CITY("rc", "收件方所在市"),
    /** 收货方所在区县 */
    RECEIPT_REGION("rr", "收货方所在区县"),

    /** 产品信息(商品编码及数量) */
    ORDER_INFO("oi", "产品信息(商品编码及数量)"),
    /** 产品总件数 */
    ORDER_SUM("os", "产品总件数"),
    /** 订单编号 */
    ORDER_NO("on", "订单编号"),
    /** 物流单号 */
    LOGISTICS_NO("oo", "物流单号"),
    /** 订单备注 */
    ORDER_REMARK("or", "订单备注"),
    /** 发票号 */
    INVOICE_NO("in", "发票号");

    /** 默认字体大小 */
    public static final int DEFAULT_FONT = 11;
    /** 需要特殊处理换行的切割符 */
    public static final String SPECIAL_SPLIT = "T_T";

    private final String name;
    private final String desc;


    /** 以字母为 key, 中文描述为 value 的 map */
    public static Map<String, Object> getInfo() {
        Map<String, Object> map = Maps.newHashMap();
        for (PrintConstant printConstant : values()) {
            map.put(printConstant.name, printConstant.desc);
        }
        return map;
    }

    /** 比较特殊的项 */
    public static List<String> getSpecialConst() {
        return Arrays.asList(ORDER_INFO.name);
    }

}
