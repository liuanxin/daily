package com.yijushang.print;

import java.util.Arrays;
import java.util.List;

/**
 * 商品发货单模板中传递的参数字符串 key
 *
 * Created on 14-9-18.
 */
public enum PrintSendConstant {

    RECEIPT_NAME("rn", "收 货 人 : "),
    EXPRESS_COMPANY("ec", "快递公司 : "),
    RECEIPT_PHONE("rp", "联系方式 : "),
    EXPRESS_NO("en", "快递单号 : "),
    RECEIPT_ADDRESS("ra", "收货地址 : "),
    RECEIPT_REMARK("rr", "买家留言 : "),

    ORDER_NO("on", "订 单 号 : "),
    SEND_NAME("sn", "发 货 人 : "),
    SEND_ADDRESS("sa", "发货地址 : "),
    SEND_REMARK("sr", "卖家留言 : "),

    /** 商品项列表 */
    ORDER_ITEMS("os", null),

    PRODUCT_NO("po", "商品编号"),
    PRODUCT_NAME("pn", "商品名称"),
    PRODUCT_PRICE("pp", "产品单价(元)"),
    PRODUCT_SUM("ps", "数量"),
    PRIVILEGE_MONEY("pm", "优惠金额(元)"),
    PRACTICE_PAY("py", "实付金额(元)"),

    /** 订单邮费, 只需要设置合计的 x 点, y 点是通过表格高度计算出来的 */
    ORDER_POSTAGE("op", "邮费 : ￥ "),
    TOTAL_PRICE("tp", "合计 : ￥ ");

    /** 默认字体 */
    public static final int DEFAULT_FONT = 11;
    /** 小一号的字体大小. 发货单中间的数据 */
    public static final int DEFAULT_SMALL_FONT = 9;
    /** 中间的表格是否虚线 */
    public static final boolean IS_LINE_DASH = true;
    /** 宽 */
    public static final float WIDTH = 595;
    /** 高 */
    public static final float HEIGHT = 410;
    /** 第一个表格的 x 点 */
    public static final float FIRST_X = 25;
    /** 第一个表格的 y 点 */
    public static final float FIRST_Y = 360;
    /** 最后一个表格的 x 点 */
    public static final float LAST_X = 445;
    /** 最后一个表格的 y 点 */
    public static final float LAST_Y = 115;
    /** 当超过多少个商品项时分页 */
    public static final int PRODUCT_ITEM_COUNT = 6;
    /** 行高 */
    public static final int ROW_HEIGHT = 14;
    /** 虚线表格行高 */
    public static final int TABLE_ROW_HEIGHT = 20;
    /** 第一个表格的列宽 */
    public static final float[] START_TABLE_WIDTH = new float[] {65, 280, 65, 120};
    /** 中间表格的列宽 */
    public static final float[] CENTER_TABLE_WIDTH = new float[] {25, 85, 205, 63, 25, 63, 63};
    /** 第三个表格的列宽 */
    public static final float[] THIRD_TABLE_WIDTH = new float[] {45, 68};
    /** 后面一个表格的列宽 */
    public static final float[] END_TABLE_WIDTH = new float[] {65, 455};

    private final String name;
    private final String desc;
    PrintSendConstant(String name, String desc) {
        this.name = name;
        this.desc = desc;
    }
    public String getName() {
        return name;
    }
    public String getDesc() {
        return desc;
    }

    /** 商品项 */
    public static List<PrintSendConstant> getTableItems() {
        return Arrays.asList(PRODUCT_NO, PRODUCT_NAME, PRODUCT_PRICE, PRODUCT_SUM, PRIVILEGE_MONEY, PRACTICE_PAY);
    }
}
