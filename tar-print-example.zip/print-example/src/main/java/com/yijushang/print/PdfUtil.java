package com.yijushang.print;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.pdf.qrcode.EncodeHintType;
import lombok.extern.slf4j.Slf4j;

import java.io.ByteArrayOutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class PdfUtil {

    /** 中文字体 */
    private static final BaseFont CHINESE_BASE_FONT;
    /** 中文字体 - 粗体 */
    private static final BaseFont CHINESE_BASE_FONT_BOLD;
    static {
        BaseFont baseFont;
        try {
            baseFont = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
        } catch (Exception e) {
            baseFont = new FontFactoryImp().getFont(FontFactory.COURIER).getBaseFont();
        }
        CHINESE_BASE_FONT = baseFont;

        BaseFont baseFontBold;
        try {
            baseFontBold = BaseFont.createFont("STSong-Light,Bold", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
        } catch (Exception e) {
            baseFontBold = new FontFactoryImp().getFont(FontFactory.COURIER_BOLD).getBaseFont();
        }
        CHINESE_BASE_FONT_BOLD = baseFontBold;
    }

    public static byte[] generatePdf(String template, Map<String, Object> data) {
        PrintInfo printInfo = JsonUtil.toObject(template, PrintInfo.class);
        if (printInfo == null || printInfo.nilData()) {
            return null;
        }
        float offsetX = printInfo.getOffsetX();
        float offsetY = printInfo.getOffsetY();

        try (ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            // 默认是 A4 格式: 宽 595, 高 842
            Document document = printInfo.hasSize() ?
                    new Document(new Rectangle(printInfo.getWidth(), printInfo.getHeight())) : new Document();

            PdfWriter writer = PdfWriter.getInstance(document, outputStream);
            document.open();
            PdfContentByte canvas = writer.getDirectContent();

            List<?> list = printInfo.pageList(data);
            if (list != null) {
                PrintInfo.PrintPlaceholderTableKey pageKey = printInfo.getPageTableContentKey();
                List<PrintInfo.PrintPlaceholderTableContent> pageList = printInfo.getPageTableContentList();

                int dataCount = list.size();
                int pageCount = pageKey.getSinglePageCount();
                int loopCount = (dataCount % pageCount == 0) ? dataCount / pageCount : (dataCount / pageCount) + 1;
                for (int i = 0; i < loopCount; i++) {
                    int fromIndex = pageCount * i;
                    int toIndex = (i + 1 == loopCount) ? dataCount : (fromIndex + pageCount);
                    draw(data, printInfo, offsetX, offsetY, canvas);
                    drawPageTable(list.subList(fromIndex, toIndex), pageKey, pageList, offsetX, offsetY, canvas);
                    document.newPage();
                }
            } else {
                draw(data, printInfo, offsetX, offsetY, canvas);
            }

            document.add(new Chunk(""));
            document.close();

            return outputStream.toByteArray();
        } catch (Exception e) {
            if (log.isErrorEnabled()) {
                log.error("生成 pdf 时异常", e);
            }
            throw new RuntimeException("生成 pdf 时异常: " + e.getMessage());
        }
    }

    private static void draw(Map<String, Object> data, PrintInfo printInfo, float offsetX, float offsetY, PdfContentByte canvas) {
        for (PrintInfo.PrintContent printContent : printInfo.getContentList()) {
            writeContent(canvas, offsetX, offsetY, printContent);
        }
        for (PrintInfo.PrintPlaceholderContent placeholderContent : printInfo.getPlaceholderContentList()) {
            writePlaceholderContent(canvas, offsetX, offsetY, placeholderContent, data);
        }
        for (Map.Entry<PrintInfo.PrintPlaceholderTable, List<PrintInfo.PrintPlaceholderTableContent>> entry
                : printInfo.getPlaceholderContentListMap().entrySet()) {
            PrintInfo.PrintPlaceholderTable table = entry.getKey();
            List<PrintInfo.PrintPlaceholderTableContent> tableContentList = entry.getValue();
            writePlaceholderTableContent(canvas, offsetX, offsetY, table, tableContentList, data);
        }
    }
    private static void drawPageTable(List<?> list, PrintInfo.PrintPlaceholderTableKey pageKey,
                                      List<PrintInfo.PrintPlaceholderTableContent> pageList,
                                      float offsetX, float offsetY, PdfContentByte canvas) {
    }

    private static void writeContent(PdfContentByte canvas, float offsetX, float offsetY, PrintInfo.PrintContent printContent) {
        writeValue(canvas, offsetX, offsetY, printContent.getX(), printContent.getY(), printContent.getSplitCount(),
                printContent.getMaxLine(), printContent.getFontSize(), printContent.getValue());
    }

    private static void writePlaceholderContent(PdfContentByte canvas, float offsetX, float offsetY,
                                                PrintInfo.PrintPlaceholderContent printContent, Map<String, Object> data) {
        Object obj = data.get(printContent.getFieldName());
        String value = (obj != null) ? obj.toString().trim() : "";

        switch (printContent.getFieldType()) {
            case LINE:
                writeLine(canvas, offsetX, offsetY, printContent.getX(), printContent.getY(),
                        printContent.getLineGray(), printContent.getLineWidth());
                break;
            case BARCODE:
                if (!value.isEmpty()) {
                    writeBarcode(canvas, offsetX, offsetY, printContent.getX(), printContent.getY(),
                            printContent.getCodeWidth(), printContent.getCodeHeight(), value);
                }
                break;
            case QRCODE:
                if (!value.isEmpty()) {
                    writeQrcode(canvas, offsetX, offsetY, printContent.getX(), printContent.getY(),
                            printContent.getCodeWidth(), printContent.getCodeHeight(), value);
                }
                break;
            default:
                if (!value.isEmpty()) {
                    writeValue(canvas, offsetX, offsetY, printContent.getX(), printContent.getY(),
                            printContent.getSplitCount(), printContent.getMaxLine(), printContent.getFontSize(), value);
                }
                break;
        }
    }

    @SuppressWarnings("unchecked")
    private static void writePlaceholderTableContent(PdfContentByte canvas, float offsetX, float offsetY,
                                                     PrintInfo.PrintPlaceholderTable tableHead,
                                                     List<PrintInfo.PrintPlaceholderTableContent> tableContentList,
                                                     Map<String, Object> data) {
        if (tableHead.notDraw() || tableContentList == null || tableContentList.isEmpty()) {
            return;
        }
        Object list = data.get(tableHead.getFieldName());
        if (!(list instanceof Collection)) {
            return;
        }

        float x = tableHead.getX();
        float y = tableHead.getY();
        float x1 = x + offsetX;
        float y1 = y + offsetY;

        List<Float> fieldWidth = tableHead.getFieldWidthList();
        PdfPTable table = new PdfPTable(fieldWidth.size());
        if (tableHead.isPrintHead()) {
            Font headFont = new Font(CHINESE_BASE_FONT, tableHead.getFontSize());
            for (String head : tableHead.getFieldHeadList()) {

                PdfPCell cell = new PdfPCell(new Phrase(handleTrim(head), headFont));
                cell.setMinimumHeight(tableHead.getHeadHeight());
                if (!tableHead.isBorder()) {
                    cell.setBorder(PdfPCell.NO_BORDER);
                }
                cell.setUseAscender(true);
                cell.setHorizontalAlignment(align);
                cell.setVerticalAlignment(Element.ALIGN_MIDDLE);
                return cell;

                table.addCell();
            }

            float[] totalWidth = new float[fieldWidth.size()];
            for (int i = 0; i < fieldWidth.size(); i++) {
                totalWidth[i] = fieldWidth.get(i);
            }
            try {
                table.setTotalWidth(totalWidth);
            } catch (DocumentException e) {
                if (log.isErrorEnabled()) {
                    log.error("设置表头宽时异常", e);
                }
            }
            table.writeSelectedRows(0, -1, x1, y1, canvas);
        }
        if (tableHead.isDashLine()) {
            canvas.setLineDash(1f, 4f, 1f);
        } else {
            canvas.setLineDash(0f, 0f, 0f);
        }

        table.addCell(getFirstTableCell1(PrintSendConstant.RECEIPT_NAME.getDesc()));
        table.addCell(getFirstTableCell1(sendPrintMap.get(PrintSendConstant.RECEIPT_NAME.getName())));
        table.addCell(getFirstTableCell1(PrintSendConstant.EXPRESS_COMPANY.getDesc()));
        table.addCell(getFirstTableCell1(sendPrintMap.get(PrintSendConstant.EXPRESS_COMPANY.getName())));

        for (Object obj : ((Collection<?>) list)) {
            if (!(obj instanceof Map)) {
                return;
            }

            Map<String, Object> map = (Map<String, Object>) obj;

            Object obj = data.get(printContent.getFieldName());
            String value = (obj != null) ? obj.toString().trim() : "";

            switch (printContent.getFieldType()) {
                case LINE:
                    writeLine(canvas, offsetX, offsetY, printContent.getX(), printContent.getY(),
                            printContent.getLineGray(), printContent.getLineWidth());
                    break;
                case BARCODE:
                    if (!value.isEmpty()) {
                        writeBarcode(canvas, offsetX, offsetY, printContent.getX(), printContent.getY(),
                                printContent.getCodeWidth(), printContent.getCodeHeight(), value);
                    }
                    break;
                case QRCODE:
                    if (!value.isEmpty()) {
                        writeQrcode(canvas, offsetX, offsetY, printContent.getX(), printContent.getY(),
                                printContent.getCodeWidth(), printContent.getCodeHeight(), value);
                    }
                    break;
                default:
                    if (!value.isEmpty()) {
                        writeValue(canvas, offsetX, offsetY, printContent.getX(), printContent.getY(),
                                printContent.getSplitCount(), printContent.getMaxLine(), printContent.getFontSize(), value);
                    }
                    break;
            }
        }
    }

    private static void writeLine(PdfContentByte canvas, float offsetX, float offsetY, float x,
                                  float y, float lineGray, float lineWidth) {
        float pageWidth = canvas.getPdfDocument().getPageSize().getWidth();
        float x1 = x + offsetX;
        float y1 = y + offsetY;
        canvas.setLineWidth(lineWidth);
        canvas.setGrayStroke(lineGray);
        canvas.moveTo(x1, y1);
        canvas.lineTo(pageWidth - x1, y1);
        canvas.stroke();
    }

    private static void writeBarcode(PdfContentByte canvas, float offsetX, float offsetY, float x, float y,
                                     float imageWidth, float imageHeight, String value) {
        float x1 = x + offsetX;
        float y1 = y + offsetY;
        try {
            Barcode128 barcode = new Barcode128();
            barcode.setCode(value);
            Image image = barcode.createImageWithBarcode(canvas, null, null);
            image.scaleAbsolute(imageWidth, imageHeight);
            image.setAbsolutePosition(x1, y1);
            canvas.addImage(image);
        } catch (DocumentException e) {
            if (log.isErrorEnabled()) {
                log.error("写 barcode 图片异常", e);
            }
        }
    }

    private static void writeQrcode(PdfContentByte canvas, float offsetX, float offsetY, float x, float y,
                                    float imageWidth, float imageHeight, String value) {
        float x1 = x + offsetX;
        float y1 = y + offsetY;
        try {
            Map<EncodeHintType, Object> hints = new HashMap<>();
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            Image image = new BarcodeQRCode(value, 100, 100, hints).getImage();
            image.scaleAbsolute(imageWidth, imageHeight);
            image.setAbsolutePosition(x1, y1);
            canvas.addImage(image);
        } catch (DocumentException e) {
            if (log.isErrorEnabled()) {
                log.error("写 qrcode 图片异常", e);
            }
        }
    }

    private static void writeValue(PdfContentByte canvas, float offsetX, float offsetY, float x, float y, int splitCount,
                                   int maxLine, float fontSize, String value) {
        if (value != null && !"".equals(value.trim())) {
            value = value.trim();
            int valueLen = value.length();
            int loopCount;
            if (valueLen > splitCount) {
                int calcCount = (valueLen % splitCount == 0) ? valueLen / splitCount : (valueLen / splitCount) + 1;
                if (maxLine > 0 && calcCount > maxLine) {
                    loopCount = maxLine;
                } else {
                    loopCount = calcCount;
                }
            } else {
                loopCount = 1;
            }

            canvas.beginText();
            canvas.setFontAndSize(CHINESE_BASE_FONT, fontSize);
            for (int i = 0; i < loopCount; i++) {
                canvas.showTextAligned(PdfContentByte.ALIGN_LEFT, handleTrim(value), (x + offsetX), (y + offsetY), 0);
                y -= (fontSize + 4);
            }
            canvas.endText();
        }
    }

    /** 英文或数字可能会因为中文字体而显得过于紧凑, 加一个空格处理一下 */
    private static String handleTrim(Object obj) {
        if (obj == null) {
            return "";
        }
        return obj.toString().replaceAll("(\\w)", " $1 ").replace("  ", " ").trim();
    }
}
