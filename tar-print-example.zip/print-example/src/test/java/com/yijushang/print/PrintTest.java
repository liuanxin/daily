package com.yijushang.print;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import org.junit.Test;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;

public class PrintTest {

    private static final String PREVIEW_PATH = "/home/ty/preview.pdf";
    private static final String PDF_PATH = "/home/ty/logistics.pdf";
    private static final String SEND_PATH = "/home/ty/send.pdf";

    private static final String TEMPLATE = "{\n" +
            "  \"sa\":[86,128,12,18],\n" +
            "  \"sd\":[349,252,0,0],\n" +
            "  \"sc\":[227,84,15,0],\n" +
            "  \"rn\":[381,87,13,0],\n" +
            "  \"ra\":[373,130,13,18],\n" +
            "  \"rt\":[522,168,0,0],\n" +
            "  \"rc\":[425,258,30,10],\n" +
            "  \"rr\":[423,290,30,11],\n" +
            "  \"rm\":[521,182,0,0],\n" +
            "  \"oi\":[112,294,0,2],\n" +
            "  \"rp\":[424,216,30,0],\n" +
            "  \"os\":[295,294,18,0],\n" +
            "  \"dy\":[\n" +
            "    [93,107,\"xxx 官方旗舰店\",0,0],\n" +
            "    [249,105,\"523129\",13,0],\n" +
            "    [205,181,\"0755-27885399\",0,0],\n" +
            "    [89,81,\"爱东爱西\",0,0],\n" +
            "    [95,174,\"已验视\",20,0]\n" +
            "  ],\n" +
            "  \"cc\":[650,360],\n" +
            "  \"ft\":[11],\n" +
            "  \"mv\":[-40,-20]\n" +
            "}";


    @Test
    public void getSize() {
        String file = "/media/sf_E_DRIVE/download/产品条码打印-1629853843-1.pdf";
        PdfReader reader = null;
        try {
            reader = new PdfReader(file);
            Rectangle page = reader.getPageSize(1);
            System.out.println(page.getHeight());
            System.out.println(page.getWidth());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                reader.close();
            }
        }
    }

    /** 预览物流单 */
    @Test
    public void previewPdf() {
        try (ByteArrayOutputStream byteArrayOutputStream = PrintUtil.previewPrintPdf(TEMPLATE,
                null, Collections.singletonList(PrintConstant.getInfo()), "xxx 电子商务", "预览物流单")) {
            byteArrayOutputStream.writeTo(new FileOutputStream(PREVIEW_PATH));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** 生成真正打印的物流单, 由浏览器渲染, chrome 自带的 pdf viewer 可以操作基本的 pdf (包含打印). */
    @Test
    public void pdf() {
        List<Map<String, Object>> mapList = Lists.newArrayList();
        for (int i = 0; i < 10; i++) {
            // 真正的过程中, 从 db 中读过来对应的数据写进去构造成 mapList
            /*Map<String, Object> map = Maps.newHashMap();
            map.put(PrintConstant.SEND_NAME.getName(), "");
            map.put(PrintConstant.SEND_ADDRESS.getName(), "");
            map.put(PrintConstant.SEND_MOBILE.getName(), "");
            map.put(PrintConstant.SEND_TELEPHONE.getName(), "");
            map.put(PrintConstant.SEND_CONTACT.getName(), "");
            map.put(PrintConstant.SEND_DATE.getName(), "");
            map.put(PrintConstant.SEND_PROVINCE.getName(), "");
            map.put(PrintConstant.SEND_CITY.getName(), "");
            map.put(PrintConstant.SEND_REGION.getName(), "");

            map.put(PrintConstant.RECEIPT_NAME.getName(), "");
            map.put(PrintConstant.RECEIPT_ADDRESS.getName(), "");
            map.put(PrintConstant.RECEIPT_MOBILE.getName(), "");
            map.put(PrintConstant.RECEIPT_CONTACT.getName(), "");
            map.put(PrintConstant.RECEIPT_TELEPHONE.getName(), "");

            map.put(PrintConstant.RECEIPT_ZIP.getName(), "");
            map.put(PrintConstant.RECEIPT_PROVINCE.getName(), "");
            map.put(PrintConstant.RECEIPT_CITY.getName(), "");
            map.put(PrintConstant.RECEIPT_REGION.getName(), "");

            map.put(PrintConstant.LOGISTICS_NO.getName(), "");

            map.put(PrintConstant.ORDER_SUM.getName(), "");
            map.put(PrintConstant.ORDER_NO.getName(), "");
            map.put(PrintConstant.ORDER_INFO.getName(), "");*/
            mapList.add(PrintConstant.getInfo());
        }

        try (ByteArrayOutputStream byteArrayOutputStream = PrintUtil.generatePrintPdf(TEMPLATE, mapList, "xxx 电子商务", "打印物流单")) {
            byteArrayOutputStream.writeTo(new FileOutputStream(PDF_PATH));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /** 发货单 */
    @Test
    public void sendPdf() {
        List<Map<String, Object>> mapList = Lists.newArrayList();
        for (int i = 0; i < 10; i++) {
            // 实际过程中, 数据fdsafdsaf来.
            Map<String, Object> map = Maps.newHashMap();
            map.put(PrintSendConstant.RECEIPT_PHONE.getName(), "fdsafdsaf");

            map.put(PrintSendConstant.RECEIPT_NAME.getName(), "fdsafdsaf");
            map.put(PrintSendConstant.RECEIPT_ADDRESS.getName(), "fdsafdsaf");
            map.put(PrintSendConstant.RECEIPT_REMARK.getName(), "fdsafdsaf");

            map.put(PrintSendConstant.SEND_NAME.getName(), "fdsafdsaf");
            map.put(PrintSendConstant.SEND_ADDRESS.getName(), "fdsafdsaf");
            map.put(PrintSendConstant.SEND_REMARK.getName(), "fdsafdsaf");

            map.put(PrintSendConstant.ORDER_NO.getName(), "fdsafdsaf");
            map.put(PrintSendConstant.ORDER_POSTAGE.getName(), "fdsafdsaf");

            map.put(PrintSendConstant.EXPRESS_COMPANY.getName(), "fdsafdsaf");
            map.put(PrintSendConstant.EXPRESS_NO.getName(), "fdsafdsaf");

            List<Map<String, Object>> orderItemMapList = Lists.newArrayList();
            // 最后一个分两页
            for (int j = 0; j < (i == 9 ? 10 : 3); j++) {
                Map<String, Object> orderItemMap = Maps.newHashMap();
                orderItemMap.put(PrintSendConstant.PRODUCT_NO.getName(), "fdsafdsaf");
                orderItemMap.put(PrintSendConstant.PRODUCT_NAME.getName(), "fdsafdsaf");
                orderItemMap.put(PrintSendConstant.PRODUCT_PRICE.getName(), "fdsafdsaf");
                orderItemMap.put(PrintSendConstant.PRODUCT_SUM.getName(), "123");

                orderItemMap.put(PrintSendConstant.PRIVILEGE_MONEY.getName(), "fdsafdsaf");
                orderItemMap.put(PrintSendConstant.PRACTICE_PAY.getName(), "fdsafdsaf");

                orderItemMapList.add(orderItemMap);
            }
            map.put(PrintSendConstant.ORDER_ITEMS.getName(), orderItemMapList);

            map.put(PrintSendConstant.TOTAL_PRICE.getName(), "fdsafdsaf");
            mapList.add(map);
        }

        try (ByteArrayOutputStream byteArrayOutputStream = PrintUtil.generateSendPdf(mapList, "xxx 电子商务", "打印发货单");) {
            byteArrayOutputStream.writeTo(new FileOutputStream(SEND_PATH));
            byte[] bytes = byteArrayOutputStream.toByteArray();
            String content = new String(Base64.getEncoder().encode(bytes), StandardCharsets.UTF_8);
            String compress = ObjectUtil.compress(content);
            System.out.println(content.length());
            System.out.println(content);
            System.out.println(compress.length());
            System.out.println(compress);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
