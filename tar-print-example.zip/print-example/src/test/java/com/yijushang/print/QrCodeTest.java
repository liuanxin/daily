package com.yijushang.print;

import com.google.common.collect.Maps;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import com.itextpdf.text.pdf.qrcode.EncodeHintType;
import org.apache.commons.lang3.StringUtils;

import javax.swing.text.StyleConstants;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;

public class QrCodeTest {

//    public static void createQR(String data, String path, int height, int width) throws WriterException, IOException {
//        Map<EncodeHintType, Object> hints = Maps.newHashMap();
//        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
//        hints.put(EncodeHintType.MARGIN, 0);
//
//        BitMatrix matrix = new MultiFormatWriter().encode(data, BarcodeFormat.QR_CODE, width, height, hints);
//
//        MatrixToImageWriter.writeToStream(matrix, path.substring(path.lastIndexOf('.') + 1), new FileOutputStream(path));
//    }
//
//    public static void createBar(String data, String path, int height, int width) throws WriterException, IOException {
//        Map<EncodeHintType, Object> hints = Maps.newHashMap();
//        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
//        hints.put(EncodeHintType.MARGIN, 0);
//
//        BitMatrix matrix = new MultiFormatWriter().encode(data, BarcodeFormat.CODE_128, width, height, hints);
//        MatrixToImageWriter.writeToStream(matrix, "png", new FileOutputStream(path));
//    }

    // Driver code
//    public static void main(String[] args) throws Exception {
//        String qrData = "abcdefghijklmnopqrstuvwxyz1234567890-=[];'中文+_}{|?><";
//        createQR(qrData, "/home/ty/qrcode.png", 150, 150);
//        System.out.println("QR Code Generated!!! ");
//
//        String barData = "RV000010-171123-0006";
//        createBar(barData, "/home/ty/code.png", 75, 445); // 90 + 450
//        System.out.println("Code Generated!!! ");

//    }


    /** 中文字体 */
    private static final BaseFont CHINESE_BASE_FONT;
    /** 中文字体 - 粗体 */
    private static final BaseFont CHINESE_BASE_FONT_BOLD;
    static {
        BaseFont baseFont;
        try {
            baseFont = BaseFont.createFont("STSong-Light", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
        } catch (Exception e) {
            baseFont = new FontFactoryImp().getFont(FontFactory.COURIER).getBaseFont();
        }
        CHINESE_BASE_FONT = baseFont;

        BaseFont baseFontBold;
        try {
            baseFontBold = BaseFont.createFont("STSong-Light,Bold", "UniGB-UCS2-H", BaseFont.NOT_EMBEDDED);
        } catch (Exception e) {
            baseFontBold = new FontFactoryImp().getFont(FontFactory.COURIER_BOLD).getBaseFont();
        }
        CHINESE_BASE_FONT_BOLD = baseFontBold;
    }

    public static void main(String... args) throws IOException, DocumentException {
        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream("/home/ty/b.pdf"));

        document.open();
        PdfContentByte canvas = writer.getDirectContent();
        System.out.println(document.getPageSize().getHeight());
        System.out.println(document.getPageSize().getWidth());

        canvas.beginText();
        canvas.setFontAndSize(CHINESE_BASE_FONT, 12);
        canvas.showTextAligned(PdfContentByte.ALIGN_LEFT, handleTrim("中文123工人"), 300, 842 - 116, 0);
        canvas.showTextAligned(PdfContentByte.ALIGN_LEFT, handleTrim("中文123abc工人"), 300, 842 - 100, 0);
        canvas.endText();

        Barcode128 barcode128 = new Barcode128();
        barcode128.setCode("ab000010-171123-0006-3012");
        Image code128Image = barcode128.createImageWithBarcode(canvas, null, null);
        code128Image.scaleAbsolute(595 - 100, 90);
        code128Image.setAbsolutePosition(50f, 842 - 230 - 50f);
        canvas.addImage(code128Image);
//        canvas.saveState();
//        canvas.rectangle(100, 100, 200, 200);
//        canvas.fill();
//        canvas.restoreState();
//        canvas.addImage(code128Image);


//        document.newPage();

        canvas.setLineWidth(0f);   // Make a bit thicker than 1.0 default
//        canvas.setGrayStroke(0.4f); // 0 = black, 1 = white
        canvas.moveTo(10D, 400D);
        canvas.lineTo(595 - 10D, 500D);
        canvas.stroke();

        Map<EncodeHintType, Object> hints = Maps.newHashMap();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        Image codeQrImage = new BarcodeQRCode("RV000013-181116-0001-168-中文-abc", 100, 100, hints).getImage();
        codeQrImage.scaleAbsolute(100, 100);
        codeQrImage.setAbsolutePosition(50f, 842 - 100 - 50f);
        canvas.addImage(codeQrImage);

        document.close();
    }

    /** 英文或数字可能会因为上面的中文字体而显得过于紧凑, 加一个空格处理一下 */
    private static String handleTrim(Object contentObj) {
        return contentObj.toString().replaceAll("(\\w)", " $1 ").replace("  ", " ").trim();
    }
}
